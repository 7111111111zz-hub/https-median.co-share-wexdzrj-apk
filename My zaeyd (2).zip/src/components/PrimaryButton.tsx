import type { ReactNode } from "react";

interface PrimaryButtonProps {
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
  children: ReactNode;
}

export default function PrimaryButton({
  onClick,
  disabled,
  loading,
  children,
}: PrimaryButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className="w-full py-3.5 rounded-xl font-bold text-white text-sm sm:text-base transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
      style={{
        background:
          "linear-gradient(135deg, var(--accent), var(--accent-2))",
        boxShadow: disabled ? "none" : "0 8px 24px -8px var(--accent)",
      }}
    >
      {loading ? "جارٍ التنفيذ..." : children}
    </button>
  );
}
