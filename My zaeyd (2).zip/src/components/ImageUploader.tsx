import { useRef, useState, type DragEvent } from "react";

interface ImageUploaderProps {
  onSelect: (file: File, previewUrl: string) => void;
  previewUrl?: string;
  label?: string;
}

export default function ImageUploader({
  onSelect,
  previewUrl,
  label = "اختر صورة أو اسحبها هنا",
}: ImageUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      alert("يرجى اختيار ملف صورة صالح");
      return;
    }
    const url = URL.createObjectURL(file);
    onSelect(file, url);
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files?.[0]);
  };

  return (
    <div
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
      className={`relative flex flex-col items-center justify-center w-full min-h-[220px] rounded-2xl border-2 border-dashed cursor-pointer transition-all overflow-hidden ${
        dragOver
          ? "border-[var(--accent)] bg-[var(--accent)]/10"
          : "border-[var(--border)] hover:border-[var(--border-hover)] bg-[var(--bg-tertiary)]"
      }`}
    >
      {previewUrl ? (
        <img
          src={previewUrl}
          alt="معاينة"
          className="w-full h-full max-h-[340px] object-contain"
        />
      ) : (
        <div className="flex flex-col items-center gap-3 p-6 text-center">
          <div className="w-14 h-14 rounded-full bg-[var(--accent)]/15 flex items-center justify-center text-2xl">
            📁
          </div>
          <p className="text-[var(--text-secondary)] text-sm">{label}</p>
          <span className="text-[var(--text-muted)] text-xs">
            JPG · PNG · WEBP
          </span>
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
