interface ResultViewProps {
  loading: boolean;
  error?: string;
  resultUrl?: string;
  loadingText?: string;
  transparent?: boolean;
}

const checkerBg =
  "repeating-conic-gradient(#2a2a3a 0% 25%, #1a1a28 0% 50%) 50% / 22px 22px";

export default function ResultView({
  loading,
  error,
  resultUrl,
  loadingText = "جارٍ المعالجة بالذكاء الاصطناعي...",
  transparent = false,
}: ResultViewProps) {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 min-h-[280px] rounded-2xl bg-[var(--bg-tertiary)] border border-[var(--border)]">
        <div className="spinner w-12 h-12 rounded-full border-4 border-[var(--border)] border-t-[var(--accent)]" />
        <p className="text-[var(--text-secondary)] text-sm">{loadingText}</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 min-h-[280px] rounded-2xl bg-red-500/10 border border-red-500/30 p-6 text-center">
        <span className="text-3xl">⚠️</span>
        <p className="text-red-300 text-sm">{error}</p>
      </div>
    );
  }

  if (resultUrl) {
    return (
      <div className="animate-fade-up flex flex-col gap-3">
        <div
          className="rounded-2xl overflow-hidden border border-[var(--border)] flex items-center justify-center"
          style={transparent ? { background: checkerBg } : undefined}
        >
          <img
            src={resultUrl}
            alt="النتيجة"
            className="w-full max-h-[420px] object-contain"
          />
        </div>
        <a
          href={resultUrl}
          target="_blank"
          rel="noopener noreferrer"
          download
          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-[var(--bg-tertiary)] border border-[var(--border)] text-[var(--text-primary)] text-sm font-medium hover:border-[var(--border-hover)] transition-all"
        >
          ⬇️ تحميل الصورة
        </a>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center gap-2 min-h-[280px] rounded-2xl bg-[var(--bg-tertiary)] border border-[var(--border)] p-6 text-center">
      <span className="text-3xl opacity-50">🖼️</span>
      <p className="text-[var(--text-muted)] text-sm">
        ستظهر النتيجة هنا بعد المعالجة
      </p>
    </div>
  );
}
