import { useState } from "react";
import { editImage } from "../lib/ai";
import { fileToBase64 } from "../lib/upload";
import ImageUploader from "../components/ImageUploader";
import ResultView from "../components/ResultView";
import PrimaryButton from "../components/PrimaryButton";

const IDEAS = [
  "غيّر الخلفية إلى شاطئ استوائي",
  "أضف نظارة شمسية أنيقة",
  "اجعلها بأسلوب رسم زيتي كلاسيكي",
  "حوّلها إلى مشهد شتوي مثلج",
];

export default function EditTab() {
  const [file, setFile] = useState<File | undefined>();
  const [preview, setPreview] = useState<string | undefined>();
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const [result, setResult] = useState<string | undefined>();

  const run = async () => {
    if (!file) {
      setError("يرجى رفع صورة أولاً");
      return;
    }
    if (!prompt.trim()) {
      setError("يرجى كتابة وصف للتعديل المطلوب");
      return;
    }
    setLoading(true);
    setError(undefined);
    setResult(undefined);
    try {
      const base64 = await fileToBase64(file);
      const url = await editImage(base64, prompt.trim());
      setResult(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ أثناء التعديل");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <ImageUploader
          previewUrl={preview}
          onSelect={(f, p) => {
            setFile(f);
            setPreview(p);
            setResult(undefined);
          }}
        />

        <div>
          <label className="block mb-2 text-sm text-[var(--text-secondary)]">
            ماذا تريد أن تعدّل؟
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={3}
            placeholder="مثال: غيّر لون القميص إلى الأزرق..."
            className="w-full p-4 rounded-xl bg-[var(--bg-tertiary)] border border-[var(--border)] text-[var(--text-primary)] text-sm resize-none outline-none focus:border-[var(--accent)] transition-all placeholder:text-[var(--text-muted)]"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {IDEAS.map((idea) => (
            <button
              key={idea}
              onClick={() => setPrompt(idea)}
              className="text-xs px-3 py-1.5 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)] transition-all"
            >
              {idea}
            </button>
          ))}
        </div>

        <PrimaryButton onClick={run} loading={loading}>
          🎨 تطبيق التعديل
        </PrimaryButton>
      </div>

      <ResultView
        loading={loading}
        error={error}
        resultUrl={result}
        loadingText="جارٍ تعديل صورتك..."
      />
    </div>
  );
}
