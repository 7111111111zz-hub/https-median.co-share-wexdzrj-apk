import { useState } from "react";
import { removeBackground } from "../lib/ai";
import { uploadImage } from "../lib/upload";
import ImageUploader from "../components/ImageUploader";
import ResultView from "../components/ResultView";
import PrimaryButton from "../components/PrimaryButton";

export default function RemoveBgTab() {
  const [file, setFile] = useState<File | undefined>();
  const [preview, setPreview] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("جارٍ إزالة الخلفية...");
  const [error, setError] = useState<string | undefined>();
  const [result, setResult] = useState<string | undefined>();

  const run = async () => {
    if (!file) {
      setError("يرجى رفع صورة أولاً");
      return;
    }
    setLoading(true);
    setError(undefined);
    setResult(undefined);
    try {
      setStatus("جارٍ رفع الصورة...");
      const imageUrl = await uploadImage(file);
      setStatus("جارٍ إزالة الخلفية بالذكاء الاصطناعي...");
      const url = await removeBackground(imageUrl);
      setResult(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ أثناء المعالجة");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <ImageUploader
          previewUrl={preview}
          onSelect={(f, p) => {
            setFile(f);
            setPreview(p);
            setResult(undefined);
          }}
        />
        <p className="text-xs text-[var(--text-muted)] leading-relaxed">
          سيتم عزل العنصر الرئيسي في الصورة وإزالة الخلفية تلقائياً مع خلفية
          شفافة جاهزة للاستخدام.
        </p>
        <PrimaryButton onClick={run} loading={loading}>
          ✂️ إزالة الخلفية
        </PrimaryButton>
      </div>

      <ResultView
        loading={loading}
        error={error}
        resultUrl={result}
        loadingText={status}
        transparent
      />
    </div>
  );
}
