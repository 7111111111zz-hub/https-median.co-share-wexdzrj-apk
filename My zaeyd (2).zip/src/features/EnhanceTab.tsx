import { useState } from "react";
import { enhanceImage } from "../lib/ai";
import { fileToBase64 } from "../lib/upload";
import ImageUploader from "../components/ImageUploader";
import ResultView from "../components/ResultView";
import PrimaryButton from "../components/PrimaryButton";

export default function EnhanceTab() {
  const [file, setFile] = useState<File | undefined>();
  const [preview, setPreview] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const [result, setResult] = useState<string | undefined>();

  const run = async () => {
    if (!file) {
      setError("يرجى رفع صورة أولاً");
      return;
    }
    setLoading(true);
    setError(undefined);
    setResult(undefined);
    try {
      const base64 = await fileToBase64(file);
      const url = await enhanceImage(base64);
      setResult(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ أثناء التحسين");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <ImageUploader
          previewUrl={preview}
          onSelect={(f, p) => {
            setFile(f);
            setPreview(p);
            setResult(undefined);
          }}
        />
        <p className="text-xs text-[var(--text-muted)] leading-relaxed">
          يعمل الذكاء الاصطناعي على رفع دقة الصورة، إزالة الضبابية والتشويش،
          وإبراز التفاصيل مع الحفاظ على المحتوى الأصلي.
        </p>
        <PrimaryButton onClick={run} loading={loading}>
          ⬆️ تحسين الجودة
        </PrimaryButton>
      </div>

      <ResultView
        loading={loading}
        error={error}
        resultUrl={result}
        loadingText="جارٍ تحسين جودة صورتك..."
      />
    </div>
  );
}
