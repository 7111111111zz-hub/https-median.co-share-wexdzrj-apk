import { useState } from "react";
import { generateImage } from "../lib/ai";
import ResultView from "../components/ResultView";
import PrimaryButton from "../components/PrimaryButton";

const SIZES = [
  { label: "مربع 1:1", value: "2K" },
  { label: "عريض 16:9", value: "2304x1296" },
  { label: "طولي 9:16", value: "1296x2304" },
];

const IDEAS = [
  "قطة فضائية ترتدي خوذة رائد فضاء، إضاءة نيون",
  "مدينة مستقبلية عند الغروب بأسلوب سينمائي",
  "قهوة الصباح على طاولة خشبية، تصوير واقعي",
  "تنين أسطوري يحلّق فوق جبال ثلجية",
];

export default function GenerateTab() {
  const [prompt, setPrompt] = useState("");
  const [size, setSize] = useState("2K");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const [result, setResult] = useState<string | undefined>();

  const run = async () => {
    if (!prompt.trim()) {
      setError("يرجى كتابة وصف للصورة أولاً");
      return;
    }
    setLoading(true);
    setError(undefined);
    setResult(undefined);
    try {
      const url = await generateImage(prompt.trim(), size);
      setResult(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ أثناء الإنشاء");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <div>
          <label className="block mb-2 text-sm text-[var(--text-secondary)]">
            صف الصورة التي تريد إنشاءها
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            placeholder="مثال: منظر طبيعي خيالي بألوان زاهية..."
            className="w-full p-4 rounded-xl bg-[var(--bg-tertiary)] border border-[var(--border)] text-[var(--text-primary)] text-sm resize-none outline-none focus:border-[var(--accent)] transition-all placeholder:text-[var(--text-muted)]"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {IDEAS.map((idea) => (
            <button
              key={idea}
              onClick={() => setPrompt(idea)}
              className="text-xs px-3 py-1.5 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)] transition-all"
            >
              {idea.slice(0, 22)}…
            </button>
          ))}
        </div>

        <div>
          <label className="block mb-2 text-sm text-[var(--text-secondary)]">
            أبعاد الصورة
          </label>
          <div className="grid grid-cols-3 gap-2">
            {SIZES.map((s) => (
              <button
                key={s.value}
                onClick={() => setSize(s.value)}
                className={`py-2.5 rounded-xl text-xs font-medium border transition-all ${
                  size === s.value
                    ? "border-[var(--accent)] bg-[var(--accent)]/15 text-white"
                    : "border-[var(--border)] bg-[var(--bg-tertiary)] text-[var(--text-secondary)]"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <PrimaryButton onClick={run} loading={loading}>
          ✨ إنشاء الصورة
        </PrimaryButton>
      </div>

      <ResultView
        loading={loading}
        error={error}
        resultUrl={result}
        loadingText="جارٍ إنشاء صورتك..."
      />
    </div>
  );
}
