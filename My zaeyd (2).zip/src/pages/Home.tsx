import { useEffect, useState } from "react";
import GenerateTab from "../features/GenerateTab";
import EditTab from "../features/EditTab";
import RemoveBgTab from "../features/RemoveBgTab";
import EnhanceTab from "../features/EnhanceTab";

type TabId = "generate" | "edit" | "removebg" | "enhance";

const TABS: { id: TabId; label: string; icon: string; desc: string }[] = [
  { id: "generate", label: "إنشاء صورة", icon: "✨", desc: "حوّل النص إلى صورة" },
  { id: "edit", label: "تعديل صورة", icon: "🎨", desc: "عدّل بأمر نصي" },
  { id: "removebg", label: "إزالة الخلفية", icon: "✂️", desc: "خلفية شفافة" },
  { id: "enhance", label: "تحسين الجودة", icon: "⬆️", desc: "رفع الدقة" },
];

export default function Home() {
  const [tab, setTab] = useState<TabId>("generate");

  useEffect(() => {
    document.documentElement.setAttribute("dir", "rtl");
    document.documentElement.setAttribute("lang", "ar");
  }, []);

  return (
    <div className="relative min-h-screen">
      {/* خلفية متحركة */}
      <div className="aurora-bg">
        <div
          className="aurora-blob"
          style={{
            width: 380,
            height: 380,
            top: "-80px",
            insetInlineStart: "-60px",
            background: "var(--accent)",
          }}
        />
        <div
          className="aurora-blob"
          style={{
            width: 320,
            height: 320,
            top: "20%",
            insetInlineEnd: "-80px",
            background: "var(--accent-2)",
            animationDelay: "4s",
          }}
        />
        <div
          className="aurora-blob"
          style={{
            width: 300,
            height: 300,
            bottom: "-60px",
            insetInlineStart: "30%",
            background: "var(--accent-3)",
            animationDelay: "8s",
          }}
        />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-4xl px-4 py-8 sm:py-12">
        {/* الترويسة */}
        <header className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[var(--bg-secondary)] border border-[var(--border)] mb-4">
            <span
              className="w-2 h-2 rounded-full"
              style={{ background: "#34d399" }}
            />
            <span className="text-xs text-[var(--text-secondary)]">
              مجاني · مدعوم بالذكاء الاصطناعي
            </span>
          </div>
          <h1
            className="text-3xl sm:text-5xl font-extrabold mb-3"
            style={{
              background: "linear-gradient(135deg, #fff, var(--accent-3))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            مساعد الصور الذكي
          </h1>
          <p className="text-[var(--text-secondary)] text-sm sm:text-base max-w-lg mx-auto">
            أنشئ، عدّل، وحسّن صورك بقوة الذكاء الاصطناعي — كل ما تحتاجه في مكان
            واحد
          </p>
        </header>

        {/* التبويبات */}
        <nav className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-col items-center gap-1 py-3 px-2 rounded-2xl border transition-all ${
                tab === t.id
                  ? "border-transparent text-white"
                  : "border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)] hover:border-[var(--border-hover)]"
              }`}
              style={
                tab === t.id
                  ? {
                      background:
                        "linear-gradient(135deg, var(--accent), var(--accent-2))",
                      boxShadow: "0 8px 20px -10px var(--accent)",
                    }
                  : undefined
              }
            >
              <span className="text-xl">{t.icon}</span>
              <span className="text-xs sm:text-sm font-bold">{t.label}</span>
              <span className="text-[10px] opacity-70 hidden sm:block">
                {t.desc}
              </span>
            </button>
          ))}
        </nav>

        {/* المحتوى */}
        <main className="rounded-3xl bg-[var(--bg-secondary)] border border-[var(--border)] p-4 sm:p-6">
          {tab === "generate" && <GenerateTab />}
          {tab === "edit" && <EditTab />}
          {tab === "removebg" && <RemoveBgTab />}
          {tab === "enhance" && <EnhanceTab />}
        </main>

        <footer className="text-center mt-8 text-xs text-[var(--text-muted)]">
          صُنع بواسطة SeaVerse · جميع العمليات مدعومة بالذكاء الاصطناعي
        </footer>
      </div>
    </div>
  );
}
