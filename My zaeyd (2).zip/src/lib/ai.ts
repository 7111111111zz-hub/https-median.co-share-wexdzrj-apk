/**
 * دوال الذكاء الاصطناعي للصور عبر seacloud-sdk.
 * كل دالة تُرجع رابط الصورة الناتجة.
 */
import {
  volcesSeedream40,
  volcesSeededit30I2i,
  quickAppBackgroundRemoverStandard,
} from "seacloud-sdk";

/** إنشاء صورة من نص. */
export async function generateImage(
  prompt: string,
  size: string = "2K"
): Promise<string> {
  const resources = await volcesSeedream40({ prompt, size });
  const url = resources?.[0]?.url;
  if (!url) throw new Error("لم يتم إرجاع صورة. حاول مرة أخرى.");
  return url;
}

/**
 * تعديل صورة بأمر نصي.
 * @param image رابط أو Base64 للصورة المدخلة
 */
export async function editImage(
  image: string,
  prompt: string
): Promise<string> {
  const resources = await volcesSeededit30I2i({
    image,
    prompt,
    response_format: "url",
    guidance_scale: 5.5,
  });
  const url = resources?.[0]?.url;
  if (!url) throw new Error("لم يتمكن من تعديل الصورة. حاول مرة أخرى.");
  return url;
}

/**
 * تحسين جودة الصورة ووضوحها (باستخدام نموذج التعديل مع أمر تحسين).
 * @param image رابط أو Base64 للصورة المدخلة
 */
export async function enhanceImage(image: string): Promise<string> {
  const resources = await volcesSeededit30I2i({
    image,
    prompt:
      "حسّن جودة الصورة وارفع دقتها ووضوحها، اجعل التفاصيل أكثر حدة ونقاءً مع الحفاظ على المحتوى الأصلي كما هو تماماً، أزل الضبابية والتشويش",
    response_format: "url",
    guidance_scale: 4,
  });
  const url = resources?.[0]?.url;
  if (!url) throw new Error("لم يتمكن من تحسين الصورة. حاول مرة أخرى.");
  return url;
}

/**
 * إزالة خلفية الصورة.
 * @param imageUrl رابط HTTP عام للصورة (مطلوب)
 */
export async function removeBackground(imageUrl: string): Promise<string> {
  const resources = await quickAppBackgroundRemoverStandard({ imageUrl });
  const url = resources?.[0]?.url;
  if (!url) throw new Error("لم يتمكن من إزالة الخلفية. حاول مرة أخرى.");
  return url;
}
