/**
 * رفع الملفات إلى التخزين السحابي عبر المتصفح.
 * يستخدم رمز المصادقة المخزَّن محلياً (نفس آلية seacloud-sdk).
 */

const RESOURCE_API = "https://resource.seaverse.ai";

function getAuthToken(): string {
  const token = localStorage.getItem("auth_token");
  if (!token) {
    throw new Error("لم يتم العثور على رمز المصادقة. يرجى إعادة تحميل الصفحة.");
  }
  return token;
}

interface PresignResponse {
  code: number;
  message?: string;
  data: {
    upload_url: string;
    cdn_url: string;
    object_path?: string;
  };
}

/**
 * ضغط الصورة وتحويلها إلى Blob بصيغة JPEG لتقليل الحجم قبل الرفع.
 */
export async function compressImage(
  file: File,
  maxSize = 1600,
  quality = 0.9
): Promise<Blob> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("فشل قراءة الملف"));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("فشل تحميل الصورة"));
    image.src = dataUrl;
  });

  let { width, height } = img;
  if (width > maxSize || height > maxSize) {
    if (width > height) {
      height = Math.round((height * maxSize) / width);
      width = maxSize;
    } else {
      width = Math.round((width * maxSize) / height);
      height = maxSize;
    }
  }

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("تعذّر معالجة الصورة");
  ctx.drawImage(img, 0, 0, width, height);

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error("فشل ضغط الصورة"));
      },
      "image/jpeg",
      quality
    );
  });
}

/**
 * رفع صورة والحصول على رابط CDN عام (مطلوب لبعض عمليات الذكاء الاصطناعي).
 */
export async function uploadImage(file: File): Promise<string> {
  const blob = await compressImage(file);
  const token = getAuthToken();

  const presignRes = await fetch(`${RESOURCE_API}/api/v1/resources/presign-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ content_type: "image/jpeg" }),
  });

  if (!presignRes.ok) {
    throw new Error("فشل تجهيز الرفع إلى الخادم");
  }

  const presign: PresignResponse = await presignRes.json();
  if (presign.code !== 0 || !presign.data?.upload_url) {
    throw new Error(presign.message || "فشل الحصول على رابط الرفع");
  }

  const putRes = await fetch(presign.data.upload_url, {
    method: "PUT",
    headers: { "Content-Type": "image/jpeg" },
    body: blob,
  });

  if (!putRes.ok) {
    throw new Error("فشل رفع الصورة إلى التخزين السحابي");
  }

  return presign.data.cdn_url;
}

/**
 * تحويل ملف إلى Base64 (لعمليات التعديل التي تقبل Base64 مباشرة).
 */
export async function fileToBase64(file: File): Promise<string> {
  const blob = await compressImage(file);
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("فشل قراءة الملف"));
    reader.readAsDataURL(blob);
  });
}
